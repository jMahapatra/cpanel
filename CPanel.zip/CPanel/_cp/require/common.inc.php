<?php
$error = array();
$success = array();
$nul="No Data";
$nul_date = "0000-00-00";
?>