--
-- Database: `cpanel_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `album_image`
--

CREATE TABLE `album_image` (
  `AI_ID` int(11) NOT NULL,
  `AI_AN_ID` int(11) NOT NULL,
  `AI_AC_ID` int(11) NOT NULL,
  `AI_Image` varchar(100) NOT NULL,
  `AI_Description` varchar(50) NOT NULL,
  `AI_Date` date NOT NULL,
  `AI_Visibility` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `album_name`
--

CREATE TABLE `album_name` (
  `AN_ID` int(11) NOT NULL,
  `AN_OI_OrganisationID` tinyint(4) NOT NULL,
  `AN_Name` varchar(100) NOT NULL,
  `AN_Image` varchar(500) NOT NULL,
  `AN_Description` varchar(200) NOT NULL,
  `AN_Date` date NOT NULL,
  `AN_Visibility` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contact_mail_us`
--

CREATE TABLE `contact_mail_us` (
  `M_ID` int(11) NOT NULL,
  `M_OI_OrganisationID` tinyint(4) NOT NULL,
  `M_Sender` varchar(100) NOT NULL,
  `M_EmailID` varchar(100) NOT NULL,
  `M_ContactNo` varchar(15) NOT NULL,
  `M_SentDt` datetime NOT NULL,
  `M_Subject` varchar(100) NOT NULL,
  `M_Message` text NOT NULL,
  `M_VeriID` varchar(100) NOT NULL COMMENT 'Verification ID',
  `M_CopySent` tinyint(1) NOT NULL COMMENT 'This field will set to 1 if send copy is checked other wise 0',
  `M_Viewed` varchar(10) NOT NULL,
  `M_ViewedDt` datetime NOT NULL,
  `M_ViewedBy` varchar(100) NOT NULL,
  `M_Replied` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='M_CopySent field will set to 1 if send copy is checked other';

-- --------------------------------------------------------

--
-- Table structure for table `contact_reply`
--

CREATE TABLE `contact_reply` (
  `CR_ID` int(11) NOT NULL,
  `CR_OI_OrganisationID` tinyint(4) NOT NULL,
  `CR_C_ID` int(11) NOT NULL,
  `CR_ReplyDetails` text NOT NULL,
  `CR_ReplyCategory` varchar(20) NOT NULL,
  `R_ReplyDt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `contact_testimonials`
--

CREATE TABLE `contact_testimonials` (
  `C_ID` int(11) NOT NULL,
  `C_SenderNm` varchar(100) NOT NULL,
  `C_EmailID` varchar(100) NOT NULL,
  `C_SendDt` date NOT NULL,
  `C_Message` text NOT NULL,
  `C_Status` tinyint(1) NOT NULL DEFAULT '0',
  `Image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `content_relatedimage`
--

CREATE TABLE `content_relatedimage` (
  `CRI_SlNo` int(11) NOT NULL,
  `CRI_ImgType` varchar(15) NOT NULL,
  `CRI_mm_QsID` smallint(6) NOT NULL,
  `CRI_sm_QsID` smallint(6) NOT NULL,
  `CRI_cm_QsID` smallint(6) NOT NULL,
  `CRI_Image` varchar(150) NOT NULL,
  `CRI_Visibility` tinyint(1) NOT NULL,
  `CRI_Desc` varchar(200) NOT NULL,
  `CRI_Position` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `latest_news`
--

CREATE TABLE `latest_news` (
  `LE_Slno` int(11) NOT NULL,
  `LE_OI_OrganisationID` tinyint(4) NOT NULL,
  `LE_NewsCatg` varchar(15) NOT NULL,
  `LE_Heading` varchar(200) NOT NULL,
  `LE_Date` date NOT NULL,
  `LE_UpdatedDate` date NOT NULL COMMENT 'Updated Date',
  `LE_UpdatedBy` varchar(100) NOT NULL,
  `LE_File` varchar(50) NOT NULL,
  `LE_Photo` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `latest_news_content`
--

CREATE TABLE `latest_news_content` (
  `LE_C_Slno` int(11) NOT NULL COMMENT 'Serial No',
  `LE_C_EventId` int(11) NOT NULL COMMENT 'Event Id',
  `LE_C_Content` text NOT NULL COMMENT 'Contents',
  `LE_C_Type` varchar(5) NOT NULL COMMENT 'Text / Image',
  `LE_C_Position` tinyint(4) NOT NULL,
  `LE_C_Status` tinyint(1) NOT NULL COMMENT 'Event Status'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Event Contents';

-- --------------------------------------------------------

--
-- Table structure for table `login_blockip`
--

CREATE TABLE `login_blockip` (
  `LB_ID` smallint(6) NOT NULL,
  `LB_IP` varchar(20) NOT NULL,
  `LB_Country` varchar(50) NOT NULL,
  `LB_State` varchar(50) NOT NULL,
  `LB_City` varchar(50) NOT NULL,
  `LB_Longitude` double NOT NULL,
  `LB_Lattitude` double NOT NULL,
  `LB_BlockedOn` datetime NOT NULL,
  `LB_UserType` varchar(30) NOT NULL,
  `LB_UserNm` varchar(50) NOT NULL,
  `LB_NoOfTries` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login_info`
--

CREATE TABLE `login_info` (
  `LI_ID` smallint(6) NOT NULL COMMENT 'User ID',
  `LI_UserName` varchar(30) NOT NULL COMMENT 'User Name',
  `LI_Password` varchar(200) NOT NULL COMMENT 'Password',
  `LI_Email` varchar(50) NOT NULL COMMENT 'EmailID',
  `LI_SecQue` varchar(50) NOT NULL COMMENT 'Security Question',
  `LI_SecAns` varchar(50) NOT NULL COMMENT 'Security Answer',
  `LI_DateCreated` datetime NOT NULL COMMENT 'Date Created',
  `LI_LastLogin` datetime NOT NULL COMMENT 'Last Login',
  `LI_Role` smallint(6) NOT NULL COMMENT 'User Role',
  `LI_PwdChangedOn` datetime NOT NULL COMMENT 'Last Password Changed',
  `LI_PwdTracker` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_info`
--

INSERT INTO `login_info` (`LI_ID`, `LI_UserName`, `LI_Password`, `LI_Email`, `LI_SecQue`, `LI_SecAns`, `LI_DateCreated`, `LI_LastLogin`, `LI_Role`, `LI_PwdChangedOn`, `LI_PwdTracker`) VALUES
(1, 'asp.admin', '@@!%#@@&&%@!@%#@!@&%@!(%#*&%%&%#@@%&%@@!%#@@&&%@@*%#', 'atreya.rath@gmail.com', 'Who is your role model ?', 'The developer does not knows yet.', '2012-04-04 14:00:57', '2012-11-23 12:41:37', 1, '2012-11-02 11:30:10', 0),
(2, 'cpanel.admin', '@@!%#@!!&%@##%#@!^&%*%#%(&%%%#$$&%&%%#$^&%', 'admin@cpanel.com', '', '', '2012-04-04 14:37:29', '2017-06-02 12:25:59', 2, '2012-10-09 12:24:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `login_role`
--

CREATE TABLE `login_role` (
  `LR_ID` smallint(6) NOT NULL,
  `LR_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_role`
--

INSERT INTO `login_role` (`LR_ID`, `LR_Name`) VALUES
(1, 'SuperAdmin'),
(2, 'Admin'),
(3, 'Student'),
(4, 'Branch');

-- --------------------------------------------------------

--
-- Table structure for table `login_status`
--

CREATE TABLE `login_status` (
  `LS_ID` smallint(6) NOT NULL,
  `LS_UserID` smallint(6) NOT NULL,
  `LS_TypeID` smallint(6) NOT NULL,
  `LS_Time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_status`
--

INSERT INTO `login_status` (`LS_ID`, `LS_UserID`, `LS_TypeID`, `LS_Time`) VALUES
(1, 1, 1, '2012-11-02 18:29:24'),
(2, 2, 1, '2015-08-22 21:37:45'),
(5, 7, 1, '2015-10-02 21:52:35');

-- --------------------------------------------------------

--
-- Table structure for table `login_statustype`
--

CREATE TABLE `login_statustype` (
  `LST_ID` smallint(6) NOT NULL,
  `LST_Name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_statustype`
--

INSERT INTO `login_statustype` (`LST_ID`, `LST_Name`) VALUES
(1, 'Approve'),
(2, 'Lock'),
(3, 'Suspend'),
(4, 'Close'),
(5, 'Remove');

-- --------------------------------------------------------

--
-- Table structure for table `login_token`
--

CREATE TABLE `login_token` (
  `LT_ID` smallint(6) NOT NULL,
  `LT_TokenID` varchar(100) NOT NULL,
  `LT_For` varchar(50) NOT NULL,
  `LT_UserNm` varchar(50) NOT NULL,
  `LT_CreatedOn` datetime NOT NULL,
  `LT_Viewed` tinyint(1) NOT NULL,
  `LT_ViewedOn` date NOT NULL,
  `LT_Used` tinyint(1) NOT NULL,
  `LT_UsedOn` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `menu_contents`
--

CREATE TABLE `menu_contents` (
  `LE_Slno` int(11) NOT NULL,
  `MenuName` varchar(50) NOT NULL,
  `LE_Heading` varchar(200) NOT NULL,
  `LE_Date` date NOT NULL,
  `LE_UpdatedDate` date NOT NULL COMMENT 'Updated Date',
  `LE_UpdatedBy` varchar(100) NOT NULL,
  `LE_File` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `menu_contents_detail`
--

CREATE TABLE `menu_contents_detail` (
  `LE_C_Slno` int(11) NOT NULL COMMENT 'Serial No',
  `LE_C_EventId` int(11) NOT NULL COMMENT 'Event Id',
  `LE_C_Content` text NOT NULL COMMENT 'Contents',
  `LE_C_Type` varchar(5) NOT NULL COMMENT 'Text / Image',
  `LE_C_Position` tinyint(4) NOT NULL,
  `LE_C_Status` tinyint(1) NOT NULL COMMENT 'Event Status'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Event Contents';

-- --------------------------------------------------------

--
-- Table structure for table `menu_master`
--

CREATE TABLE `menu_master` (
  `Category_ID` smallint(6) NOT NULL,
  `Parent_ID` smallint(6) NOT NULL,
  `CategoryName` varchar(50) NOT NULL,
  `RedirectPath` text NOT NULL,
  `position` smallint(6) NOT NULL,
  `InMenu` varchar(3) NOT NULL,
  `IsActive` varchar(3) NOT NULL,
  `IsDeleted` varchar(3) NOT NULL COMMENT 'yes / no',
  `LastUpdate` datetime NOT NULL,
  `UpdatedBy` varchar(30) NOT NULL COMMENT 'Login Id'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `update_detail`
--

CREATE TABLE `update_detail` (
  `Notice_ID` int(11) NOT NULL,
  `Updates` varchar(150) NOT NULL,
  `UploadDate` date NOT NULL,
  `UploadBy` varchar(50) NOT NULL,
  `IsActive` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `upl_document`
--

CREATE TABLE `upl_document` (
  `DocumentID` int(11) NOT NULL,
  `FileFor` varchar(20) NOT NULL,
  `Subject` varchar(200) NOT NULL,
  `Description` varchar(1000) NOT NULL,
  `FileName` varchar(50) NOT NULL,
  `UplDate` date NOT NULL,
  `IsBlock` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `album_image`
--
ALTER TABLE `album_image`
  ADD PRIMARY KEY (`AI_ID`),
  ADD KEY `AI_AM_ID` (`AI_AN_ID`),
  ADD KEY `AI_AC_ID` (`AI_AC_ID`);

--
-- Indexes for table `album_name`
--
ALTER TABLE `album_name`
  ADD PRIMARY KEY (`AN_ID`);

--
-- Indexes for table `contact_mail_us`
--
ALTER TABLE `contact_mail_us`
  ADD PRIMARY KEY (`M_ID`);

--
-- Indexes for table `contact_reply`
--
ALTER TABLE `contact_reply`
  ADD PRIMARY KEY (`CR_ID`),
  ADD KEY `CR_C_ID` (`CR_C_ID`);

--
-- Indexes for table `contact_testimonials`
--
ALTER TABLE `contact_testimonials`
  ADD PRIMARY KEY (`C_ID`);

--
-- Indexes for table `content_relatedimage`
--
ALTER TABLE `content_relatedimage`
  ADD PRIMARY KEY (`CRI_SlNo`);

--
-- Indexes for table `latest_news`
--
ALTER TABLE `latest_news`
  ADD PRIMARY KEY (`LE_Slno`);

--
-- Indexes for table `latest_news_content`
--
ALTER TABLE `latest_news_content`
  ADD PRIMARY KEY (`LE_C_Slno`),
  ADD KEY `LE_C_EventId` (`LE_C_EventId`);

--
-- Indexes for table `login_blockip`
--
ALTER TABLE `login_blockip`
  ADD PRIMARY KEY (`LB_ID`);

--
-- Indexes for table `login_info`
--
ALTER TABLE `login_info`
  ADD PRIMARY KEY (`LI_ID`),
  ADD KEY `CL_UserName` (`LI_UserName`),
  ADD KEY `CL_Role` (`LI_Role`);

--
-- Indexes for table `login_role`
--
ALTER TABLE `login_role`
  ADD PRIMARY KEY (`LR_ID`);

--
-- Indexes for table `login_status`
--
ALTER TABLE `login_status`
  ADD PRIMARY KEY (`LS_ID`),
  ADD KEY `CST_UserID` (`LS_UserID`),
  ADD KEY `CST_TypeID` (`LS_TypeID`);

--
-- Indexes for table `login_statustype`
--
ALTER TABLE `login_statustype`
  ADD PRIMARY KEY (`LST_ID`);

--
-- Indexes for table `login_token`
--
ALTER TABLE `login_token`
  ADD PRIMARY KEY (`LT_ID`);

--
-- Indexes for table `menu_contents`
--
ALTER TABLE `menu_contents`
  ADD PRIMARY KEY (`LE_Slno`);

--
-- Indexes for table `menu_contents_detail`
--
ALTER TABLE `menu_contents_detail`
  ADD PRIMARY KEY (`LE_C_Slno`),
  ADD KEY `LE_C_EventId` (`LE_C_EventId`);

--
-- Indexes for table `menu_master`
--
ALTER TABLE `menu_master`
  ADD PRIMARY KEY (`Category_ID`),
  ADD KEY `CategoryName` (`CategoryName`),
  ADD KEY `UpdatedBy` (`UpdatedBy`),
  ADD KEY `Parent_ID` (`Parent_ID`);

--
-- Indexes for table `update_detail`
--
ALTER TABLE `update_detail`
  ADD PRIMARY KEY (`Notice_ID`);

--
-- Indexes for table `upl_document`
--
ALTER TABLE `upl_document`
  ADD PRIMARY KEY (`DocumentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `album_image`
--
ALTER TABLE `album_image`
  MODIFY `AI_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `album_name`
--
ALTER TABLE `album_name`
  MODIFY `AN_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contact_mail_us`
--
ALTER TABLE `contact_mail_us`
  MODIFY `M_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contact_reply`
--
ALTER TABLE `contact_reply`
  MODIFY `CR_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `contact_testimonials`
--
ALTER TABLE `contact_testimonials`
  MODIFY `C_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `content_relatedimage`
--
ALTER TABLE `content_relatedimage`
  MODIFY `CRI_SlNo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `latest_news`
--
ALTER TABLE `latest_news`
  MODIFY `LE_Slno` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `latest_news_content`
--
ALTER TABLE `latest_news_content`
  MODIFY `LE_C_Slno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Serial No';
--
-- AUTO_INCREMENT for table `login_blockip`
--
ALTER TABLE `login_blockip`
  MODIFY `LB_ID` smallint(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `login_info`
--
ALTER TABLE `login_info`
  MODIFY `LI_ID` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'User ID', AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `login_role`
--
ALTER TABLE `login_role`
  MODIFY `LR_ID` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `login_status`
--
ALTER TABLE `login_status`
  MODIFY `LS_ID` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `login_statustype`
--
ALTER TABLE `login_statustype`
  MODIFY `LST_ID` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `login_token`
--
ALTER TABLE `login_token`
  MODIFY `LT_ID` smallint(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menu_contents`
--
ALTER TABLE `menu_contents`
  MODIFY `LE_Slno` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `menu_contents_detail`
--
ALTER TABLE `menu_contents_detail`
  MODIFY `LE_C_Slno` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Serial No';
--
-- AUTO_INCREMENT for table `menu_master`
--
ALTER TABLE `menu_master`
  MODIFY `Category_ID` smallint(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `update_detail`
--
ALTER TABLE `update_detail`
  MODIFY `Notice_ID` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `upl_document`
--
ALTER TABLE `upl_document`
  MODIFY `DocumentID` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
